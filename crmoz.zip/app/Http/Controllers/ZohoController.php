<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\User;
use App\Services\ZohoApi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Inertia\Inertia;

class ZohoController extends Controller
{
    public $zohoApi;

    public function __construct(ZohoApi $zohoApi)
    {
        $this->zohoApi = $zohoApi;
    }

    public function login()
    {
        $user = Auth::User();
        //$user = User::where(['id' => $user_id])->first();
       // var_export(!empty($user->access_token)); die;
        if(!empty($user->access_token)) {
            return redirect('/zoho/list');
        } else {
            //var_dump($this->zohoApi->getLoginUrl()); die;
            return Inertia::location($this->zohoApi->getLoginUrl());
        }
    }

    public function getTokens(Request $request)
    {
        $this->zohoApi->getTokens($request);
    }

    public function list()
    {
        //$accounts = Account::getAll();


        return Inertia::render('AccountsDeals', [

        ]);
    }

    public function createAccount()
    {


        return Inertia::render('AccountDealForm', [

        ]);
    }
}
